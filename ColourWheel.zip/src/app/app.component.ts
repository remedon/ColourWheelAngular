import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'chart-donut';

  public pieChartType:string = 'doughnut';

  public pieChartLabels:string[] = [""];
  public pieChartData:number[] = [360];

  public pieChartColors: Array<any> = [
    {backgroundColor: ['#999999']}
  ];
  // events on slice click
  public chartClicked(e:any):void {
    // console.log(e);
  }
 
 // event on pie chart slice hover
  public chartHovered(e:any):void {
    // console.log(e);
  }

  public colorDefault: string = '#2889e9';

  public onEventLog(event: string, data: any): void {
    // console.log(event, data);
  }

  public onChangeColor(event: string, data: any): void {
    // console.log(data);
    // console.log(event, data);
    if(this.pieChartLabels.length==1 && this.pieChartLabels[0]==="") {
      // console.log(this.pieChartLabels);
      // console.log(this.pieChartColors);
      
      this.pieChartColors.slice();
      
      this.pieChartLabels[0] = "Data1"
      this.pieChartColors = [{backgroundColor: [data]} ];

      // console.log(this.pieChartLabels);
      // console.log(this.pieChartColors);
    }
    else {
      console.log("2");
      this.pieChartLabels.push("Data" + (this.pieChartLabels.length + 1));
      var angle = 360 / (this.pieChartData.length + 1);
      for(var i = 0; i < this.pieChartData.length; i++) {
          this.pieChartData[i] = angle;
      }
      this.pieChartData.push(angle);

      const clone = JSON.parse(JSON.stringify(this.pieChartColors));
      this.pieChartColors.slice();
      clone[0].backgroundColor.push(data);
      this.pieChartColors = clone;
    }
  }
}
